<?php
include '../assets/db/functions.php';
checkUser();
$pageTitle = "Electro.";
$pageContent="main.php";
include "structure/template.php";
