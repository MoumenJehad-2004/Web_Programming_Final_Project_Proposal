<?php
include '../../assets/db/functions.php';
checkUser();
$pageTitle = "Electro-Categories Management";
$pageContent="ordersList.php";
include "../structure/template.php";
