<?php
include '../../assets/db/functions.php';
checkUser();
$pageTitle = "Electro-Categories Management";
$pageContent="usersArchiveList.php";
include "../structure/template.php";
