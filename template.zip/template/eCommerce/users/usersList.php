<div class="col-xs-12">
				<div class="box-content">
					<div  class="dataTables_wrapper form-inline dt-bootstrap"><div class="row"><div class="col-sm-12">
                        <table id="UsersList" class="table cell-border " style="width:85%;" >
						<thead>
                            <th class="fs-6" rowspan="1" colspan="1">#</th>
                            <th class="fs-6" rowspan="1" colspan="1">Name</th>
                            <th class="fs-6" rowspan="1" colspan="1">Email </th>
						    <th class="fs-6" rowspan="1" colspan="1">Type </th>
						    <th class="fs-6" rowspan="1" colspan="1">Status </th>
						    <th class="fs-6" rowspan="1" colspan="1">Operations </th>
                        </thead>
						<tbody id="ShowUser">
			           </tbody>
                      </table>
			        </div>
			    </div>
</div>
