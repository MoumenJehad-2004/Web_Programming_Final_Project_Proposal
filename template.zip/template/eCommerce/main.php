  <style>
    .welcome{
    display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
height: 400px;  }
 .wel{
    color:#1f0b0b;
   margin-top: 25px;
  text-align: center;
  font-size: 30px;
  font-weight: 100;
 }
    </style>
         <img class="welcome" src="assets/images/find.png">
         <p class="wel">Welcome  <?=$_SESSION['username']?> to Electro. dashboard</p>
