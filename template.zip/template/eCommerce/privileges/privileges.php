<?php
include '../../assets/db/functions.php';
checkUser();
$pageTitle = "Electro-Privileges Management";
$pageContent="privilegesList.php";
include "../structure/template.php";
