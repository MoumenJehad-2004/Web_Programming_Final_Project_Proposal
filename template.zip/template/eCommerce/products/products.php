<?php
include '../../assets/db/functions.php';
checkUser();
$pageTitle = "Electro-Categories Management";
$pageContent="productsList.php";
include "../structure/template.php";
