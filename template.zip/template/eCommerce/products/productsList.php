
<div class="col-xs-12">
				<div class="box-content">
					<button type="button" class="mdc-button mdc-button--raised margin-bottom-10 waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#AddProductModal">Add New</button><div class="clearfix">&nbsp;</div>
					<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap"><div class="row"><div class="col-sm-12">
                        <table id="ProductsList" class="table table-striped table-bordered display dataTable" style="width: 100%;" role="grid" aria-describedby="example_info">
						<thead>
                            <th class="fs-6" rowspan="1" colspan="1">#</th>
                            <th class="fs-6" rowspan="1" colspan="1">Name</th>
                            <th class="fs-6" rowspan="1" colspan="1">Category</th>
                            <th class="fs-6" rowspan="1" colspan="1">Price</th>
                            <th class="fs-6" rowspan="1" colspan="1">Quantity</th>
                            <th class="fs-6" rowspan="1" colspan="1">Description</th>
                            <th class="fs-6" rowspan="1" colspan="1">Status</th>
                            <th class="fs-6" rowspan="1" colspan="1">Image</th>
						    <th class="fs-6" rowspan="1" colspan="1">Operations </th>
                        </thead>
						<tbody id="ShowProduct">
			           </tbody>        
					</table>
			</div>

</div>
</div>