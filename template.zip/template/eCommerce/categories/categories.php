<?php
include '../../assets/db/functions.php';
checkUser();
$pageTitle = "Electro-Categories Management";
$pageContent="categoriesList.php";
include "../structure/template.php";
