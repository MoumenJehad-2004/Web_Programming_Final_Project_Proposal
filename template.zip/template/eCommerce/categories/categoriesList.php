<div class="col-xs-12">
				<div class="box-content">
					<button id="add-category" type="button" class="mdc-button mdc-button--raised margin-bottom-10 waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#AddCategoryModal">Add New</button>					<div class="clearfix">&nbsp;</div>
					<div  class="dataTables_wrapper form-inline dt-bootstrap"><div class="row"><div class="col-sm-12">
                        <table id="CategoriesList" class="table table-striped table-bordered display dataTable" style="width:85%;" >
						<thead>
                            <th class="fs-6" rowspan="1" colspan="1">#</th>
                            <th class="fs-6" rowspan="1" colspan="1">Name</th>
                            <th class="fs-6" rowspan="1" colspan="1">Status </th>
						    <th class="fs-6" rowspan="1" colspan="1">Operations </th>
                        </thead>
						<tbody id="ShowCategory">
			           </tbody>
                      </table>
			</div>
</div>
