$(function(){
    $("#CategoriesList").DataTable();
    $("#ProductsList").DataTable();
    $("#UsersList").DataTable();
    $("#UsersArchiveList").DataTable();
    showCategory();
    ShowProduct();
    showCategoryList();
    showUser();
    showUserArchive();
    function showCategory() {
    $.ajax({
      type: "ajax",
      dataType: "json",
      async: false,
      url: "eCommerce/categories/get_category.php",
      success: function (data) {
        var i;
        var html="";
        var status;
        for(i=0; i < data.length; i++){
            if (data[i].status==1){
                status="Active";
            }
            else{
                status="Diactive"
            }
              html +=
                "<tr><td class='fs-6 text-center' >" +
                data[i].id +
                "</td><td class='fs-6 text-center'>" +
                data[i].name +
                "</td><td class='fs-6 text-center'>" +
                status +
                "</td><td class='fs-6 text-center'>" +
                '<a  class="mdc-button mdc-button--raised filled-button--success mdc-ripple-upgraded w-50 edit_record" data-id="' +
                data[i].id +
                '"data-name="' +
                data[i].name +
                '" data-status="' +
                data[i].status +
                '">Edit Category</a>' +
                "</td></tr>";
         }
        $("#ShowCategory").html(html);
        console.log("done");
    },
    error:function(e){
      console.log(e);
    }
});

    }
    function showCategoryList(){
      $.ajax({
        type: "ajax",
        dataType: "json",
        async: false,
        url: "eCommerce/categories/get_category_list.php",
        success: function (data) {
            var i;
            var list='<option value="">Select Category</option>';
            for(i=0;i<data.length;i++){
                var id=data[i].id;
                list+='<option value="'+data[i].id+'">'+data[i].name+'</option>';
                $('#category').html(list);
            }
        }});
    }
    $("#add-category-btn").click((e) => {
      e.preventDefault();
      console.log("hi");
     // var form = $("#add-category").serialize();
      var form = document.forms.namedItem("add-category");
      var id = $("#id").val();
      var name = $("#name").val();
      console.log(name + "hi");
      var status = $("#status").val();
      if (name == "" || status == "") {
        Swal.fire({
          title: "Fill all Required inputs",
          icon: "warning",
          confirmButtonColor: "#d33",
          confirmButtonText: "Ok",
        });
      }else {  
        $.ajax({
          type: "post",
          url: "eCommerce/categories/process.php?id=" + id,
          dataType: "json",
          cache: false,
          contentType: false,
          processData: false,
          data: new FormData(form),
          success() {
            Swal.fire({
              icon: "success",
              title: "Your work has been saved",
              showConfirmButton: false,
              timer: 1500,
            }).then(() => {
              $('[name="name"').val("");
              $('[name="status"').val("");
              $("#AddCategoryModal").modal("hide");
              location.reload();
            });
          },
          error(e) {
            console.log(e);
          },
        });
      }
    });
    $("#ShowCategory").on("click", ".edit_record", function () {
      $("#exampleModalLabel").html("Edit User");
      var id = $(this).data("id");
      console.log(id);
      var name = $(this).data("name");
      var status = $(this).data("status");
      $('[name="id"').val(id);
      $('[name="name"').val(name);
      $('[name="status"').val(status); 
      $("#AddCategoryModal").modal("show");
    });
    function ShowProduct() {
      $.ajax({
        type: "ajax",
        dataType: "json",
        async: false,
        url: "eCommerce/products/get_product.php",
        success: function (data) {
          var i;
          var html = "";
          var status;
          var image;
          for (i = 0; i < data.length; i++) {
            if (data[i].status == 1) {
              status = "Active";
            } else {
              status = "Diactive";
            }
             if (data[i].image == "") {
               image =
                 '<img src="assets/images/my-folder/no-image.png" class="img-thumbnial" width="50" height="50">';
             } else {
               image =
                 '<img src="assets/images/my-folder/' +
                 data[i].image +
                 '" class="img-thumbnial" width="50" height="50">';
             }
            html +=
              "<tr><td class='fs-6'>" +
              data[i].id +
              "</td><td class='fs-6'>" +
              data[i].name +
              "</td><td class='fs-6'>" +
              data[i].categoryName +
              "</td><td class='fs-6'>" +
              data[i].price +
              "</td><td class='fs-6'>" +
              data[i].quantity +
              "</td><td class='fs-6'>" +
              data[i].description +
              "</td><td class='fs-6'>" +
              status +
              "</td><td class='fs-6'>" +
              image +
              "</td><td class='fs-6'>" +
              '<a  class="edit_record" data-id="' +
              data[i].id +
              '" data-name="' +
              data[i].name +
              '" data-category="' +
              data[i].category +
              '" data-price="' +
              data[i].price +
              '" data-quantity="' +
              data[i].quantity +
              '" data-description="' +
              data[i].description +
              '" data-status="' +
              data[i].status +
              '" data-image="' +
              data[i].image +
              '"><i class="fa-regular fa-pen-to-square fa-xl" style="color: #027d40;"></i></a> &nbsp;&nbsp; <a class="delete_record" data-id="' +
              data[i].id +
              '" data-image="' +
              data[i].image +
              '" ><i class="fa-solid fa-trash fa-xl" style="color: #f00000;"></i></a> ' +
              "</td></tr>";
          }
          $("#ShowProduct").html(html);
          console.log("done");
        },
        error: function (e) {
          console.log(e);
        },
      });
    }  
    $("#add-product-btn").click((e) => {
      e.preventDefault();
      console.log("hi");
      var form = document.forms.namedItem("add-product");
      var id = $("#id").val();
      var name = $("#name").val();
      var category = $("#category").val();
      var price = $("#price").val();
      var quantity = $("#quantity").val();
      var description = $("#description").val();
      var status = $("#status").val();
      var imgFle = $("#imgFle").val();
      var status = $("#status").val();
      console.log(name + "hi");
        $.ajax({
          type: "post",
          url: "eCommerce/products/process.php?id=" + id,
          dataType: "json",
          cache: false,
          contentType: false,
          processData: false,
          data: new FormData(form),
          success() {
            Swal.fire({
              icon: "success",
              title: "Your work has been saved",
              showConfirmButton: false,
              timer: 1500,
            }).then(() => {
              $('[name="name"').val("");
              $('[name="category"').val("");
              $('[name="price"').val("");
              $('[name="quantity"').val("");
              $('[name="description"').val("");
              $('[name="status"').val("");
              $('[name="imgFle"').val("");
              $("#AddProductModal").modal("hide");
              location.reload();
            });
          },
          error(e) {
            console.log(e);
          },
        });
      }
    );
    $("#ShowProduct").on("click", ".edit_record", function () {
      var id = $(this).data("id");
      console.log(id);
      var name = $(this).data("name");
      var category = $(this).data("category");
      var price = $(this).data("price");
      var quantity = $(this).data("quantity");
      var description = $(this).data("description");
      var status = $(this).data("status");
      var image = $(this).data("image");
      $('[name="id"').val(id);
      $('[name="name"').val(name);
      $('[name="category"').val(category);
      $('[name="price"').val(price);
      $('[name="quantity"').val(quantity);
      $('[name="description"').val(description);
      $('[name="status"').val(status);
      $('[name="oldImage"').val(image);
      if (image == "") {
        $("#photo").html('<img src="../../assets/images/my-folder/no-image.png" class="img-thumbnial" width="50" height="50">');
      } else {
        $("#photo").html('<img src="../../images/my-folder/' +image +'" class="img-thumbnial" width="50" height="50">');
      }
      $("#AddProductModal").modal("show");
    });
    $("#ShowProduct").on("click", ".delete_record", function () {
      var id = $(this).data("id");
      var img = $(this).data("image");
      console.log("Hi", img);
      $('[name="id"').val(id);
      $('[name="oldImage"').val(img);
      Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
          var id = $("#id").val();
          var img = $("#oldImage").val();
          $.ajax({
            url: "eCommerce/products/delete_record.php?id=" + id + "&oldImage=" + img,
            type: "POST",
            dataType: "json",
            success: function (data) {
              console.log(data);
            },
          });
          Swal.fire({
            icon: "success",
            title: "Your work has been Deleted",
            showConfirmButton: false,
            timer: 1500,
          }).then(() => {
            $('[name="id"').val("");
            location.reload();
          });
        }
      });
    });
    function showUser() {
      $.ajax({
        type: "ajax",
        dataType: "json",
        async: false,
        url: "eCommerce/users/get_user.php",
        success: function (data) {
          var i;
          var html = "";
          var type ;
          var status;
          for (i = 0; i < data.length; i++) {
            if (data[i].type==1){
              type = "Admin";
            }
            else{
              type = "user";
            }
            if (data[i].status== 1) {
              status = "Active";
            } else {
              status = "Diactive";
            }
            html +=
              "<tr><td >" +
              data[i].id +
              "</td><td>" +
              data[i].name +
              "</td><td>" +
              data[i].email +
              "</td><td>" +
              type +
              '</td><td>'+
              status +
              '</td><td class="text-center">' +
              '<button type="button" class="ml-3 mr-3 mdc-button mdc-button--raised filled-button--secondary privileges" data-id="' +
              data[i].id +
              '" data-privilege="' +
              data[i].privilege +
              '"  data-category="' +
              data[i].category +
              '"  data-product="' +
              data[i].product +
              '">Privileges</button>' +
              '<button type="button" class="mdc-button mdc-button--raised filled-button--success mdc-ripple-upgraded users" data-id="' +
              data[i].id +
              '" data-status="' +
              data[i].status +
              '">Edit-user</button>' +
              "</td></tr>";
          }
          $("#ShowUser").html(html);
          console.log("done");
        },
        error: function (e) {
          console.log(e);
        },
      });
    }
     function showUserArchive() {
       $.ajax({
         type: "ajax",
         dataType: "json",
         async: false,
         url: "eCommerce/users/get_archive.php",
         success: function (data) {
           var i;
           var html = "";
           var type;
           var status;
           for (i = 0; i < data.length; i++) {
             if (data[i].type == 1) {
               type = "Admin";
             } else {
               type = "user";
             }
             if (data[i].status == 1) {
               status = "Active";
             } else {
               status = "Diactive";
             }
             html +=
               "<tr><td >" +
               data[i].id +
               "</td><td>" +
               data[i].name +
               "</td><td>" +
               data[i].email +
               "</td><td>" +
               type +
               "</td><td>" +
               status +
               '</td><td class="text-center">' +
               '<button type="button" class="mdc-button mdc-button--raised filled-button--success mdc-ripple-upgraded users" data-id="' +
               data[i].id +
               '" data-status="' +
               data[i].status +
               '">Edit-user</button>' +
               "</td></tr>";
           }
           $("#ShowUserArchive").html(html);
           console.log("done");
         },
         error: function (e) {
           console.log(e);
         },
       });
     }
    $("#ShowUser").on("click", ".privileges", function () {
      var id = $(this).data("id");
      var priv = $(this).data("privilege");
      var cat = $(this).data("category");
      var pro = $(this).data("product");
      $("#EditPriv").modal("show");
      $('[name="uprivid"').val(id);
      $('[name="pro"').val(pro);
      $('[name="cat"').val(cat);
      $('[name="priv"').val(priv);
    });     
    $("#btn_priv").click(function () {
      var form = document.forms.namedItem("priv");
      var uid = $("#uprivid").val();
      $.ajax({
        url: "eCommerce/users/process.php?id=" + uid,
        type: "POST",
        dataType: "json",
        cache: false,
        contentType: false,
        processData: false,
        data: new FormData(form),
        success: function (data) {
          console.log(data);
          if (data.status == "success") {
            alert(data.msg);
          }
          $("#EditPriv").modal("hide");
          location.reload();
        },
      });
    });
    $("#ShowUser").on("click", ".users", function () {
      var id = $(this).data("id");
      var status = $(this).data("status");
      $("#EditUser").modal("show");
      $('[name="uprivid"').val(id);
      $('[name="status"').val(status);
      console.log(status+"click");
    });
    $("#btn_user").click(function () {
        var form = document.forms.namedItem("user");
        var uid = $("#uprivid").val();
        $.ajax({
          url: "eCommerce/users/update.php?id=" + uid,
          type: "POST",
          dataType: "json",
          cache: false,
          contentType: false,
          processData: false,
          data: new FormData(form),
          success: function (data) {
            console.log(data);
            if (data.status == "success") {
              alert(data.msg);
            }
            $("#EditUser").modal("hide");
            location.reload();
          },
        });
    });
    $("#ShowUserArchive").on("click", ".users", function () {
      var id = $(this).data("id");
      var status = $(this).data("status");
      $("#EditUser").modal("show");
      $('[name="uprivid"').val(id);
      $('[name="status"').val(status);
      console.log(status + "click");
    });
    $("#btn_user").click(function () {
      var form = document.forms.namedItem("user");
      var uid = $("#uprivid").val();
      $.ajax({
        url: "eCommerce/users/update.php?id=" + uid,
        type: "POST",
        dataType: "json",
        cache: false,
        contentType: false,
        processData: false,
        data: new FormData(form),
        success: function (data) {
          console.log(data);
          if (data.status == "success") {
            alert(data.msg);
          }
          $("#EditUser").modal("hide");
          location.reload();
        },
      });
    });
    });


    