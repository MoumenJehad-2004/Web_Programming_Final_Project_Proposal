<?php session_start();
    // Connect with DB
    function Connect(){
        $conn = mysqli_connect('localhost', 'root','','electro_db');
        return $conn;
    }
  //Execute Query
    function dbQuery($sql){
        $result = mysqli_query(Connect(),$sql);
        return $result;
    }

    //Store the returned result index in array
    function dbFetchArray($result, $resultType='MYSQLI_NUM'){
        return mysqli_fetch_array($result);
     }
   //Store the returned result column name in array
   function dbFetchAssoc($result){
    return mysqli_fetch_assoc($result);
   }

   // Return No of Records in Table

   function dbNumRows($result){
    return mysqli_num_rows($result);
   }

     function DoLogin()
     {
      $errormessage = "";
      $username = $_POST['username'];
      $password = $_POST['password'];
      if($username == '' && $password == ''){
        $errormessage = 'Please Enter Username and Password';
      }else{
        $sql = "Select id,type FROM user where username = '$username' and password ='$password'";
        $rs = dbQuery($sql);
        if(dbNumRows($rs) == 1 ){
        $row = dbFetchAssoc($rs);
        if($row['type'] == 1){
        $_SESSION['id'] = $row['id'];
        $_SESSION['username'] =  $username;
        $_SESSION['type'] = $row['type'];
        header('location:index.php');
        exit();
        }else{
          $id =  $row['id'] ;
          $sql3 = "SELECT * FROM user where `id` = $id";
          $rs = dbQuery($sql3);
          if(dbNumRows($rs)==1){
            $rows = dbFetchAssoc($rs);
            $_SESSION['id'] = $rows['id'];
            $_SESSION['username'] =  $username;
            $_SESSION['type'] = $rows['type'];
            $_SESSION['privilege'] = $rows['privilege'];
            $_SESSION['category'] = $rows['category'];
            $_SESSION['product'] = $rows['product'];
            header("location:index.php");
            exit;
          }
        }
        }
        else{
          $errormessage = 'Please Enter Correct Username Or Password';
        }
      }
      return $errormessage;
    }
     
    function DoLoginEnd(){
      $errormessage = "";
      $username = $_POST['username'];
      $password = $_POST['password'];
      if($username == '' && $password == ''){
        $errormessage = 'Please Enter Username and Password';
      }
      else{
          $sql = "Select id FROM user_end where name = '$username' and password ='$password'";
           $rs = dbQuery($sql);
           if(dbNumRows($rs) >0)
           {
            $row = dbFetchAssoc($rs);
            $_SESSION['id'] = $row['id'];
            $_SESSION['name'] = $username;
            $_SESSION['pass'] = $password;
            header('location:index.php');
           }
        else
        {
          $errormessage = 'Please Enter Correct Username Or Password';
        }
      }
          return $errormessage;
}
      
    
     function checkUser(){
      if(!isset($_SESSION['id'])){
        header('location:login.php');
      }
     }
?>     